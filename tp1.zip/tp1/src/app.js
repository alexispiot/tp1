const express = require('express');

const server = express();

const mongoose = require("mongoose");
mongoose.connect('mongodb://localhost:3000/apinodejs');  // Without docker;

server.use(express.urlencoded());
server.use(express.json());



const postRoute = require("./routes/postRoute");
postRoute(server);

server.listen(3000);

server.listen(port, hostname);