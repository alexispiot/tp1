


const commentController = require('../controllers/commentController');

module.exports = (server) => {
    server.route("/comments")
    .get(commentController.readAllComment) // Get all posts
    .post(commentController.createAcomment); // Create a comment
    
    server.route("/comments/:comment_id") // req.params.comment_id
    .get(commentController.readAComment) // Get one comments
    .put(commentController.updateAComment) // Update one comment
    .delete(commentController.deleteComment); // Delete one commment
}