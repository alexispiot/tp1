const comment = require('../models/commentModel');

// Get all comments
exports.readAllcomment = (req, res) => {
    comment.find({}, (error, comments) => {
        if(error){
            res.status(500);
            console.log(error);
            res.end({message: "Erreur serveur."});
        }
        else {
            res.status(200);
            res.json({
                count : comments.length,
                comments
            });
        }
    });
}

// Create a comment
exports.createAcomment = (req, res) => {
    // {
    //     title: "Mon premeir article",
    //     content: "toto"
    // }
    let newcomment = new comment(req.body);

    newcomment.save((error, comment) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(201);
            res.json(comment);
        }
    });
}


// Get a comment
exports.readAcomment = (req, res) => {
    comment.findById(req.params.comment_id, (error, comment) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json(comment);
        }
    });
}

// Update a comment
exports.updateAcomment = (req, res) => {
    comment.findByIdAndUpdate(req.params.comment_id, req.body, {new: true}, (error, comment) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json(comment);
        }
    });
}

// Delete a comment
exports.deleteAcomment = (req, res) => {
    comment.findByIdAndDelete(req.params.comment_id, (error) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json({message: "Article supprimé"});
        }
    });
}