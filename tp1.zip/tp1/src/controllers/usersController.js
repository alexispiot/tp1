


const user = require('../models/userModel');

// Get all users
exports.readAlluser = (req, res) => {
    User.find({}, (error, users) => {
        if(error){
            res.status(500);
            console.log(error);
            res.end({message: "Erreur serveur."});
        }
        else {
            res.status(200);
            res.json({
                count : users.length,
                users
            });
        }
    });
}

// Create a user
exports.createAuser = (req, res) => {
    // {
    //     title: "Mon premeir article",
    //     content: "toto"
    // }
    let newuser = new User(req.body);

    newUser.save((error, user) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(201);
            res.json(user);
        }
    });
}


// Get a user
exports.readAuser = (req, res) => {
    User.findById(req.params.user_id, (error, user) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json(user);
        }
    });
}

// Update a user
exports.updateAuser = (req, res) => {
    User.findByIdAndUpdate(req.params.user_id, req.body, {new: true}, (error, user) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json(user);
        }
    });
}

// Delete a user
exports.deleteAuser = (req, res) => {
    User.findByIdAndDelete(req.params.user_id, (error) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json({message: "Article supprimé"});
        }
    });
}




















