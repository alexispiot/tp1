const  bcrypt  =  require ( 'bcrypt' ) ;
const  saltRounds  =  10 ;
const  myPlaintextPassword  =  's0/\/\P4$$w0rD' ;
const  someOtherPlaintextPassword  =  'not_bacon' ;

bcrypt.genSalt(saltRounds, function(err, salt) {
    bcrypt.hash(myPlaintextPassword, salt, function(err, hash) {
        // Store hash in your password DB.
    });
});

bcrypt.compare(myPlaintextPassword, hash, function(err, result) {
    // result == true
});
bcrypt.compare(someOtherPlaintextPassword, hash, function(err, result) {
    // result == false
});

async function checkUser(username, password) {
    //... fetch user from a db etc.

    const match = await bcrypt.compare(password, user.passwordHash);

    if(match) {
        //login
    }

    //...
}

module.exports = bcrypt.model('Password', passwordSchema);
